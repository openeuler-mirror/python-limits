"""
errors and exceptions
"""


class ConfigurationError(Exception):
    """
    exception raised when a configuration problem
    is encountered
    """
    pass
